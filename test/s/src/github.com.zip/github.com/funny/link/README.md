[English](http://github.com/funny/link/blob/master/README_EN.md)
---------

[中文说明](http://github.com/funny/link/blob/master/README_CN.md)
---------