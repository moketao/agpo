package link

import (
	"encoding/binary"
	"io"
	"math"
	"unicode/utf8"
)

// Big endian message buffer factory.
type BufferFactoryBE struct {
}

// Create a big endian incoming message buffer.
func (_ BufferFactoryBE) NewInBuffer() InBuffer {
	return new(InBufferBE)
}

// Create a big endian outgoing message buffer.
func (_ BufferFactoryBE) NewOutBuffer() OutBuffer {
	return new(OutBufferBE)
}

// Little endian message buffer factory.
type BufferFactoryLE struct {
}

// Create a little endian incoming message buffer.
func (_ BufferFactoryLE) NewInBuffer() InBuffer {
	return new(InBufferLE)
}

// Create a little endian outgoing message buffer.
func (_ BufferFactoryLE) NewOutBuffer() OutBuffer {
	return new(OutBufferLE)
}

// In/Out message buffer base.
type BufferBase struct {
	b []byte
}

// Get internal buffer.
func (m *BufferBase) Get() []byte {
	return []byte(m.b)
}

// Get buffer length.
func (m *BufferBase) Len() int {
	return len(m.b)
}

// Get buffer capacity.
func (m *BufferBase) Cap() int {
	return cap(m.b)
}

// Copy buffer data.
func (m *BufferBase) Copy() []byte {
	b := make([]byte, len(m.b))
	copy(b, m.b)
	return b
}

/*
Incoming
*/

// The base type of incoming message buffer.
type InBufferBase struct {
	BufferBase
	i int
}

// Implement io.Reader interface.
func (m *InBufferBase) Read(p []byte) (int, error) {
	if m.i == len(m.b) {
		return 0, io.EOF
	}
	n := copy(p, m.b[m.i:])
	m.i += n
	return n, nil
}

// Prepare buffer for next read.
func (m *InBufferBase) Prepare(size int) {
	if cap(m.b) >= size {
		m.b = m.b[0:size]
	} else {
		m.b = make([]byte, size)
	}
	m.i = 0
}

// Slice some bytes from buffer.
func (m *InBufferBase) ReadSlice(n int) []byte {
	r := m.b[m.i : m.i+n]
	m.i += n
	return r
}

// Copy some bytes from buffer.
func (m *InBufferBase) ReadBytes(n int) []byte {
	r := make([]byte, n)
	copy(r, m.ReadSlice(n))
	return r
}

// Read a string from buffer.
func (m *InBufferBase) ReadString(n int) string {
	return string(m.ReadSlice(n))
}

// Read a rune from buffer.
func (m *InBufferBase) ReadRune() rune {
	r, size := utf8.DecodeRune(m.b[m.i:])
	m.i += size
	return r
}

// Read a byte value from buffer.
func (m *InBufferBase) ReadByte() byte {
	r := m.b[m.i]
	m.i += 1
	return r
}

// Read a int8 value from buffer.
func (m *InBufferBase) ReadInt8() int8 {
	r := int8(m.b[m.i])
	m.i += 1
	return r
}

// Read a uint8 value from buffer.
func (m *InBufferBase) ReadUint8() uint8 {
	r := uint8(m.b[m.i])
	m.i += 1
	return r
}

/*
big endian
*/

// Big endian incoming message.
type InBufferBE struct {
	InBufferBase
}

// Read a big endian int16 value from buffer.
func (m *InBufferBE) ReadInt16() int16 {
	return int16(m.ReadUint16())
}

// Read a big endian uint16 value from buffer.
func (m *InBufferBE) ReadUint16() uint16 {
	r := binary.BigEndian.Uint16(m.b[m.i:])
	m.i += 2
	return r
}

// Read a big endian int32 value from buffer.
func (m *InBufferBE) ReadInt32() int32 {
	return int32(m.ReadUint32())
}

// Read a big endian uint32 value from buffer.
func (m *InBufferBE) ReadUint32() uint32 {
	r := binary.BigEndian.Uint32(m.b[m.i:])
	m.i += 4
	return r
}

// Read a big endian int64 value from buffer.
func (m *InBufferBE) ReadInt64() int64 {
	return int64(m.ReadUint64())
}

// Read a big endian int50 value from buffer. AS3 的Number只能精确表达50位的整数，再多就有偏差。
func (m *InBufferBE) ReadInt50() int64 {
	b := m.b[m.i:]
	u := uint64(b[7]) | uint64(b[6])<<8 | uint64(b[5])<<16 | uint64(b[4])<<24 |
		uint64(b[3])<<32 | uint64(b[2])<<40 | uint64(b[1])<<48
	var fu int64
	if uint64(b[0]) == 0 {
		fu = -1
	} else {
		fu = 1
	}
	return int64(u) * fu
}

// Read a big endian uint64 value from buffer.
func (m *InBufferBE) ReadUint64() uint64 {
	r := binary.BigEndian.Uint64(m.b[m.i:])
	m.i += 8
	return r
}

// Read a float32 value from buffer.
func (m *InBufferBE) ReadFloat32() float32 {
	return math.Float32frombits(m.ReadUint32())
}

// Read a float64 value from buffer.
func (m *InBufferBE) ReadFloat64() float64 {
	return math.Float64frombits(m.ReadUint64())
}

/*
little endian
*/

// Little endian incoming message.
type InBufferLE struct {
	InBufferBase
}

// Read a little endian int16 value from buffer.
func (m *InBufferLE) ReadInt16() int16 {
	return int16(m.ReadUint16())
}

// Read a little endian uint16 value from buffer.
func (m *InBufferLE) ReadUint16() uint16 {
	r := binary.LittleEndian.Uint16(m.b[m.i:])
	m.i += 2
	return r
}

// Read a little endian int32 value from buffer.
func (m *InBufferLE) ReadInt32() int32 {
	return int32(m.ReadUint32())
}

// Read a little endian uint32 value from buffer.
func (m *InBufferLE) ReadUint32() uint32 {
	r := binary.LittleEndian.Uint32(m.b[m.i:])
	m.i += 4
	return r
}

// Read a little endian int64 value from buffer.
func (m *InBufferLE) ReadInt64() int64 {
	return int64(m.ReadUint64())
}

// Read a little endian int50 value from buffer. AS3 的Number只能精确表达50位的整数，再多就有偏差。
func (m *InBufferLE) ReadInt50() int64 {
	b := m.b[m.i:]
	u := uint64(b[0]) | uint64(b[1])<<8 | uint64(b[2])<<16 | uint64(b[3])<<24 |
		uint64(b[4])<<32 | uint64(b[5])<<40 | uint64(b[6])<<48
	var fu int64
	if uint64(b[7]) == 0 {
		fu = -1
	} else {
		fu = 1
	}
	return int64(u) * fu
}

// Read a little endian uint64 value from buffer.
func (m *InBufferLE) ReadUint64() uint64 {
	r := binary.LittleEndian.Uint64(m.b[m.i:])
	m.i += 8
	return r
}

// Read a float32 value from buffer.
func (m *InBufferLE) ReadFloat32() float32 {
	return math.Float32frombits(m.ReadUint32())
}

// Read a float64 value from buffer.
func (m *InBufferLE) ReadFloat64() float64 {
	return math.Float64frombits(m.ReadUint64())
}

/*
Outgoing
*/

// The base type of outgoing message buffer.
type OutBufferBase struct {
	BufferBase
}

// Implement io.Writer interface.
func (m *OutBufferBase) Write(d []byte) (int, error) {
	m.b = append(m.b, d...)
	return len(d), nil
}

// Prepare buffer for next write.
func (m *OutBufferBase) Prepare(size int) {
	if cap(m.b) >= size {
		m.b = m.b[0:0]
	} else {
		m.b = make([]byte, 0, size)
	}
}

// Write a byte slice into buffer.
func (m *OutBufferBase) WriteBytes(d []byte) {
	m.b = append(m.b, d...)
}

// Write a string into buffer.
func (m *OutBufferBase) WriteString(s string) {
	m.b = append(m.b, s...)
}

// Write a rune into buffer.
func (m *OutBufferBase) WriteRune(r rune) {
	p := []byte{0, 0, 0, 0}
	n := utf8.EncodeRune(p, r)
	m.b = append(m.b, p[:n]...)
}

// Write a byte value into buffer.
func (m *OutBufferBase) WriteByte(v byte) {
	m.b = append(m.b, v)
}

// Write a int8 value into buffer.
func (m *OutBufferBase) WriteInt8(v int8) {
	m.b = append(m.b, byte(v))
}

// Write a uint8 value into buffer.
func (m *OutBufferBase) WriteUint8(v uint8) {
	m.b = append(m.b, byte(v))
}

/*
big endian
*/

// Big endian format outgoing message buffer.
type OutBufferBE struct {
	OutBufferBase
}

// Write a byte slice into buffer.
func (m *OutBufferBE) WriteBytes(d []byte) {
	m.b = append(m.b, d...)
}

// Write a string into buffer.
func (m *OutBufferBE) WriteString(s string) {
	m.b = append(m.b, s...)
}

// Write a rune into buffer.
func (m *OutBufferBE) WriteRune(r rune) {
	p := []byte{0, 0, 0, 0}
	n := utf8.EncodeRune(p, r)
	m.b = append(m.b, p[:n]...)
}

// Write a byte value into buffer.
func (m *OutBufferBE) WriteByte(v byte) {
	m.b = append(m.b, v)
}

// Write a big endian int16 value into buffer.
func (m *OutBufferBE) WriteInt16(v int16) {
	m.WriteUint16(uint16(v))
}

// Write a big endian uint16 value into buffer.
func (m *OutBufferBE) WriteUint16(v uint16) {
	m.b = append(m.b, byte(v>>8), byte(v))
}

// Write a big endian int32 value into buffer.
func (m *OutBufferBE) WriteInt32(v int32) {
	m.WriteUint32(uint32(v))
}

// Write a big endian uint32 value into buffer.
func (m *OutBufferBE) WriteUint32(v uint32) {
	m.b = append(m.b, byte(v>>24), byte(v>>16), byte(v>>8), byte(v))
}

// Write a big endian int64 value into buffer.
func (m *OutBufferBE) WriteInt64(v int64) {
	m.WriteUint64(uint64(v))
}

// Write a big endian uint64 value into buffer.
func (m *OutBufferBE) WriteUint64(v uint64) {
	m.b = append(m.b,
		byte(v>>56),
		byte(v>>48),
		byte(v>>40),
		byte(v>>32),
		byte(v>>24),
		byte(v>>16),
		byte(v>>8),
		byte(v),
	)
}

// Write a big endian int50 value into buffer. AS3 的Number只能精确表达50位的整数，再多就有偏差。
func (m *OutBufferBE) WriteInt50(v int64) {
	//符号，0为负，1为正
	var fu byte
	if v < 0 {
		fu = byte(0)
		v = v * -1
	} else {
		fu = byte(1)
	}

	m.b = append(m.b,
		fu,
		byte(v>>48),
		byte(v>>40),
		byte(v>>32),
		byte(v>>24),
		byte(v>>16),
		byte(v>>8),
		byte(v),
	)
}

// Write a float32 value into buffer.
func (m *OutBufferBE) WriteFloat32(v float32) {
	m.WriteUint32(math.Float32bits(v))
}

// Write a float64 value into buffer.
func (m *OutBufferBE) WriteFloat64(v float64) {
	m.WriteUint64(math.Float64bits(v))
}

/*
little endian
*/

// Little endian format outgoing message buffer.
type OutBufferLE struct {
	OutBufferBase
}

// Write a little endian int16 value into buffer.
func (m *OutBufferLE) WriteInt16(v int16) {
	m.WriteUint16(uint16(v))
}

// Write a little endian uint16 value into buffer.
func (m *OutBufferLE) WriteUint16(v uint16) {
	m.b = append(m.b, byte(v), byte(v>>8))
}

// Write a little endian int32 value into buffer.
func (m *OutBufferLE) WriteInt32(v int32) {
	m.WriteUint32(uint32(v))
}

// Write a little endian uint32 value into buffer.
func (m *OutBufferLE) WriteUint32(v uint32) {
	m.b = append(m.b, byte(v), byte(v>>8), byte(v>>16), byte(v>>24))
}

// Write a little endian int64 value into buffer.
func (m *OutBufferLE) WriteInt64(v int64) {
	m.WriteUint64(uint64(v))
}

// Write a little endian int50 value into buffer. AS3 的Number只能精确表达50位的整数，再多就有偏差。
func (m *OutBufferLE) WriteInt50(v int64) {
	//符号，0为负，1为正
	var fu byte
	if v < 0 {
		fu = byte(0)
		v = v * -1
	} else {
		fu = byte(1)
	}

	m.b = append(m.b,
		byte(v>>8),
		byte(v>>16),
		byte(v>>24),
		byte(v>>32),
		byte(v>>40),
		byte(v>>48),
		byte(v>>56),
		fu,
	)
}

// Write a little endian uint64 value into buffer.
func (m *OutBufferLE) WriteUint64(v uint64) {
	m.b = append(m.b,
		byte(v),
		byte(v>>8),
		byte(v>>16),
		byte(v>>24),
		byte(v>>32),
		byte(v>>40),
		byte(v>>48),
		byte(v>>56),
	)
}

// Write a float32 value into buffer.
func (m *OutBufferLE) WriteFloat32(v float32) {
	m.WriteUint32(math.Float32bits(v))
}

// Write a float64 value into buffer.
func (m *OutBufferLE) WriteFloat64(v float64) {
	m.WriteUint64(math.Float64bits(v))
}
